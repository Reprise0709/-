clear;
x = [0 : 0.1 : 9.5];
%%A = input('Please input A: ');
%%B = input('Please inout B: ');
y = sqrt(x) ./ (exp(x-5)+1);
%plot(x, y);
z = [0 : 0.1 : 9.5];
for i = 1 : 94
    z(i) = quadl(inline('sqrt(x) ./ (exp(x)+1)'), 0, x(i));
end;
z = 3.5-5.*(z);
plot(x, z);
axis([0 9 0 5]);
xlabel('E');
ylabel('n');