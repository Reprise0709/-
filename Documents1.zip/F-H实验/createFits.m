function [fitresult, gof] = createFits(x1, y1, x2, y2, x3, y3)
%CREATEFITS(X1,Y1,X2,Y2,X3,Y3)
%  Create fits.
%
%  Data for 'untitled fit 1' fit:
%      X Input : x1
%      Y Output: y1
%  Data for 'untitled fit 8' fit:
%      X Input : x2
%      Y Output: y2
%  Data for 'untitled fit 9' fit:
%      X Input : x3
%      Y Output: y3
%  Output:
%      fitresult : a cell-array of fit objects representing the fits.
%      gof : structure array with goodness-of fit info.
%
%  ������� FIT, CFIT, SFIT.

%  �� MATLAB �� 10-Dec-2017 20:59:58 �Զ�����

%% Initialization.

% Initialize arrays to store fits and goodness-of-fit.
fitresult = cell( 3, 1 );
gof = struct( 'sse', cell( 3, 1 ), ...
    'rsquare', [], 'dfe', [], 'adjrsquare', [], 'rmse', [] );

%% Fit: 'untitled fit 1'.
[xData, yData] = prepareCurveData( x1, y1 );

% Set up fittype and options.
ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.Normalize = 'on';
opts.SmoothingParam = 0.99980816442071;

% Fit model to data.
[fitresult{1}, gof(1)] = fit( xData, yData, ft, opts );

% Plot fit with data.
%figure( 'Name', 'untitled fit 1' );
plot( fitresult{1}, 'b', xData, yData );
hold on;
% Label axes
xlabel x1
ylabel y1
grid on

%% Fit: 'untitled fit 8'.
[xData, yData] = prepareCurveData( x2, y2 );

% Set up fittype and options.
ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.SmoothingParam = 0.983582101816763;

% Fit model to data.
[fitresult{2}, gof(2)] = fit( xData, yData, ft, opts );

% Plot fit with data.
%figure( 'Name', 'untitled fit 8' );
plot( fitresult{2}, 'g', xData, yData );
hold on;
% Label axes
xlabel x2
ylabel y2
grid on

%% Fit: 'untitled fit 9'.
[xData, yData] = prepareCurveData( x3, y3 );

% Set up fittype and options.
ft = fittype( 'smoothingspline' );
opts = fitoptions( 'Method', 'SmoothingSpline' );
opts.SmoothingParam = 0.918908201183146;

% Fit model to data.
[fitresult{3}, gof(3)] = fit( xData, yData, ft, opts );

% Plot fit with data.
%figure( 'Name', 'untitled fit 9' );
plot( fitresult{3},  'r' , xData, yData );
hold on;
% Label axes
xlabel U
ylabel I(10^-^8A)
grid on


