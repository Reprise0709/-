clear;
x = [0.100 0.200 0.340 0.500 0.800 1.000 1.300 1.400];
y = [2.00 4.00 7.00 10.16 16.40 20.44 26.76 28.48];
p = polyfit(x, y, 1);
scatter(x, y, 'x');
xlabel('U / V');
ylabel('I / mA');
axis([0 1.500 0 30.00]);
grid on;
title('R1�ķ�����������');
lsline