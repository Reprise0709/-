 clear;
x = [0.50 1.50 2.50 3.50 5.00 6.00 7.00];
y = [0.50 1.51 2.52 3.54 5.02 6.003 7.04];
p = polyfit(x, y, 1);
scatter(x, y, 'x');
xlabel('U / V');
ylabel('I / mA');
axis([0 7.50 0 7.50]);
grid on;
title('R2�ķ�����������');
lsline