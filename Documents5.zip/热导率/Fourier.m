clc
clear
t = -90 : 0.1 : 90;
T0 = 0 : 0.1 : 180;
T = zeros(1, 1801);
for i = 1 : 901
    T0(i) = (i - 1) / 900;
end;
for i = 901 : 1801
    T0(i) = -(i - 901) / 900 + 1;
end;
figure
plot(t, T0);
c = [4/pi^2 0 4/(9*pi^2) 0 4/(25*pi^2) 0 4/(49*pi^2) 0 4/(81*pi^2)];
for i = 1 : 9
    T = T + c(i) * cos(i * 0.0349 * t);
end;
T = T + 0.5;
hold on
plot(t, T);
%axis([0  0 2])
