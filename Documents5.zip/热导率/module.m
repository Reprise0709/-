clear
clc
x = 0 : 0.02 : 0.2;
t = 0 : 0.1 : 200;
T = zeros(11, 2001);
T1 = zeros(11, 2001);
c = [4/pi^2 0 4/(9*pi^2) 0 4/(25*pi^2) 0 4/(49*pi^2) 0 4/(81*pi^2)];
for i = 1 : 9
        for j = 1 : 11
            for k = 1 : 2001
                if (i == 1)
                    T1(j, k) = T1(j, k) + exp(-sqrt(i) * 12.7 * x(j)) * cos(i * 0.0349 * t(k) - 12.72 * x(j));
                end
                T(j, k) = T(j, k) + c(i) * exp(-sqrt(i) * 12.7 * x(j)) * cos(i * 0.0349 * t(k) - 12.72 * x(j));
            end
        end
end
T = T * 2;
figure
for j = 1 : 11
    plot(t, T(j, :));
    hold on
    plot(t, T1(j, :), 'LineStyle', '--');
    hold on
end;
MAX = 1 : 1 : 11;
MAXt = 1 : 1 : 11;
for j = 1 : 11
    [MAX(j), MAXt(j)] = max(T(j,1  : 1000));
    plot(MAXt(j) * 0.1, MAX(j), 'x');
    hold on
end;
N = 1 : 11
figure
MAXt = MAXt / 10;
plot(MAXt, 'x');

