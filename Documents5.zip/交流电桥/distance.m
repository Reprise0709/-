function d = distance(Ax, Ay, Bx, By)
    d = sqrt((Ax - Bx)^2 + (Ay - By)^2);
end