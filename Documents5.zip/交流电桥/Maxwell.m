%%���˹Τ�ŵ��ڹ��̵�ģ��
clc
clear
phi = 3.14;
f = 1005.7;
Lx = 9.69 * 1e-3;
RL = 103.6;
R1 = 200.3;
R2 = 200;
R0 = 100;
L0 = 10 * 1e-3;
n = 1;
delta_R0 = 100;
delta_R2 = 100;
Ax = R2 * RL;
Ay = R2 * 2 * phi * f * Lx;
Bx = R1 * R0;
By = R1 * 2 * phi * f * L0;
d0 = distance(Ax, Ay, Bx, By);
Axx = 1 : 1 : 100;
Bxx = 1 : 1 : 100;
Ayy = 1 : 1: 100;
Byy = 1 : 1: 100;
while(1)
    delta_R0 = 100;
    delta_R2 = 100;
    while (1)
        Bx1 = R1 * (R0 + delta_R0);
        if (distance(Ax, Ay, Bx1, By) < d0)
            R0 = R0 + delta_R0;
            d0 = distance(Ax, Ay, Bx1, By);
            continue;
        end;
        Bx1 = R1 * (R0 - delta_R0);
        if (distance(Ax, Ay, Bx1, By) < d0)
            R0 = R0 - delta_R0;
            d0 = distance(Ax, Ay, Bx1, By);
            continue;
        end;
        if (delta_R0 <= 0.1)
            break;
        else
            delta_R0 = delta_R0 / 10;
        end    
    end
    Ax = R2 * RL;
    Ay = R2 * 2 * phi * f * Lx;
    Bx = R1 * R0;
    By = R1 * 2 * phi * f * L0;
    d0 = distance(Ax, Ay, Bx, By);
    Axx(n) = Ax;
    Ayy(n) = Ay;
    Bxx(n) = Bx;
    Byy(n) = By;
    n = n + 1;
    while (1)
        Ax1 = (R2 + delta_R2) * RL;
        Ay1 = (R2 + delta_R2) * 2 * phi * f * Lx;
        if (distance(Ax1, Ay1, Bx, By) < d0)
            R2 = R2 + delta_R2;
            d0 = distance(Ax1, Ay1, Bx, By);
            continue;
        end;
        Ax1 = (R2 - delta_R2) * RL;
        Ay1 = (R2 - delta_R2) * 2 * phi * f * Lx;
        if (distance(Ax1, Ay1, Bx, By) < d0)
            R2 = R2 - delta_R2;
            d0 = distance(Ax1, Ay1, Bx, By);
            continue;
        end;
        if (delta_R2 <= 0.1)
            break;
        else
            delta_R2 = delta_R2 / 10;
        end
    end
    Ax = R2 * RL;
    Ay = R2 * 2 * phi * f * Lx;
    Bx = R1 * R0;
    By = R1 * 2 * phi * f * L0;
    d0 = distance(Ax, Ay, Bx, By);
    Axx(n) = Ax;
    Ayy(n) = Ay;
    Bxx(n) = Bx;
    Byy(n) = By;
    n = n + 1;
    if (d0 < 15) 
        break;
    end
end
plot(Axx(1 : n - 1), Ayy(1 : n - 1), 'o');
hold on
plot(Axx(1 : n - 1), Ayy(1 : n - 1));
hold on
plot(Bxx(1 : n - 1), Byy(1 : n - 1), 'x');
hold on
plot(Bxx(1 : n - 1), Byy(1 : n - 1));

xlabel('Re(Z)(��)')
ylabel('Im(Z)(��)')
title('Maxwell����������ʾ��ͼ');

    
